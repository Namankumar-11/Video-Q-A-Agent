"""
captioner.py
------------
Every CAPTION_EVERY_N_SECONDS, we send a frame to a vision-language model
and ask it to describe the scene in plain English. This is what lets the
system answer *semantic* questions ("was anyone wearing a helmet?") that
raw object-detection labels alone can't cover — YOLO gives you "person",
a VLM caption can give you "a person wearing a red helmet crossing the
street."
"""

import base64
import cv2
from groq import Groq
import config


class SceneCaptioner:
    def __init__(self, api_key=config.GROQ_API_KEY, model=config.VISION_MODEL):
        if not api_key:
            raise ValueError(
                "GROQ_API_KEY not set. Get a free key at https://console.groq.com "
                "and export it as an environment variable."
            )
        self.client = Groq(api_key=api_key)
        self.model = model

    def _frame_to_base64(self, frame):
        # VLM APIs take images as base64-encoded JPEG, not raw numpy arrays
        success, buffer = cv2.imencode(".jpg", frame)
        if not success:
            raise RuntimeError("Failed to encode frame as JPEG")
        return base64.b64encode(buffer).decode("utf-8")

    def caption_frame(self, frame, active_tracks):
        """
        active_tracks: list of class_names currently visible (from detector.py),
        passed in as extra grounding so the VLM's description references what
        was actually detected rather than hallucinating unrelated objects.
        """
        b64_image = self._frame_to_base64(frame)
        detected_objects = ", ".join(sorted(set(active_tracks))) or "none detected"

        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": (
                            "Describe what is happening in this video frame in one or two "
                            "concise sentences. Focus on actions, positions, and notable "
                            f"visual details. Objects detected by the tracker: {detected_objects}. "
                            "Only describe what you can actually see."
                        ),
                    },
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/jpeg;base64,{b64_image}"},
                    },
                ],
            }],
            temperature=0.2,   # low temperature — we want grounded description, not creativity
            max_tokens=150,
        )
        return response.choices[0].message.content.strip()
